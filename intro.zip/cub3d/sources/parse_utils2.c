/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parse_utils.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rrangwan <rrangwan@42abudhabi.ae>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/09 02:00:52 by rrangwan          #+#    #+#             */
/*   Updated: 2022/07/29 19:01:26 by rrangwan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <cub3D.h>

char	*ft_strdup2(const char *s1)
{
	char	*dup;

	dup = (char *)ft_calloc((ft_strlen(s1) + 1), sizeof(char));
	if (!dup)
		return (NULL);
	ft_memcpy(dup, s1, ft_strlen(s1));
	dup[ft_strlen2(s1)] = '\0';
	return (dup);
}

int	ft_strlen2(const char *s)
{
	int	i;

	i = 0;
	while (s[i])
		i++;
	return (i);
}
