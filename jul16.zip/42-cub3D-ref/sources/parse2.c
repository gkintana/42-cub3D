/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parse2.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gkintana <gkintana@student.42abudhabi.ae>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/09 02:00:52 by gkintana          #+#    #+#             */
/*   Updated: 2022/07/09 02:01:03 by gkintana         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <cub3D.h>

/*Now checking if the map is valid
 */

char	**ft_temp_map(char **map_temp, char *str)
{
	char	**new_temp;
	int		rows;
	int		i;

	// if(!map_temp)
	// 	rows = 0;
	// else
	rows = ft_array_len(map_temp);
	
	
	new_temp = (char **)malloc(sizeof(char *) * (rows + 2));
	if (!new_temp)
		return (NULL);
	i = 0;
	while(map_temp[i])
	{
		new_temp[i] = ft_strdup(map_temp[i]);
		i++;
	}
	new_temp[i] = ft_strdup(str);
	new_temp[i + 1] = NULL;
	//printf("printing ft_temp_map %s \n", new_temp[i]);
	free(map_temp);
	return(new_temp);
}






//return 0 if ok
int	check_map(char **map)
{
	write(1, "\033c", 3);
	printf("map checking work under process\n");
	if (check_chars(map))
		return (1);
	if (check_top(map) || check_bottom(map) || check_left(map) || check_right(map))
		return (1);
	write(1, "\033c", 3);
	printf("map ok \n");
	
		
	return(0);
}

// //return 1 if error
int	check_top(char **map)
{
	printf("checking top row\n");
	int		i;
	int		j;
	int flag = 0;
	int max_check;

	if(ft_map_row(map[0]) == 0)
		return (1);
	i = 0;
	j = 0;
	max_check = ft_strlen(map[j]) * 3;
	while(ft_isspace(map[j][i]) && map[j][i + 1] != '\n')
	{
		i++;
		printf("j %d, i %d \n", j,i);
		
	}
	if(!map[j][i])
		return (1);
	while(map[j][i + 1] != '\n')
	{
		while (map[j][i] == '1' && map[j][i + 1] == '1' && (j == 0 || (j > 0  && map[j - 1][i] != '1')))
		{
		i++;
		printf("j %d, i %d \n", j,i);
		
		}
		flag++;
		while (map[j][i] == '1' && map[j + 1][i] && map[j + 1][i] == '1' && map[j][i + 1] == ' ')
				{
				
				j++;
				printf("j %d, i %d \n", j,i);
				}
		flag++;
				//printf("hereree\n");
		while (map[j][i] == '1' && map[j][i + 1] == '1' && (j == 0 || (j > 0 && map[j - 1][i + 1] != '0')))
			{
			i++;
			printf("j %d, i %d \n", j,i);
			//printf("hereree\n");
			}
			flag++;
			//printf("hereree\n");
		while (map[j][i] == '1' && j > 0 && i > 0 && map[j - 1][i - 1] == ' ' && map[j - 1][i] == '1')
		{
			j--;
			printf("j %d, i %d \n", j,i);
		}
		flag++;
		// while (map[j][i] == '1' && map[j][i + 1] == '1' && (j == 0 || (j > 0 && map[j -1][i + 1] && map[j - 1][i + 1] == '1')))
		// {
		// 	i++;
		// 	printf("j %d, i %d \n", j,i);
		// }
		// flag++;
		
		if ( flag > max_check)
			break ;	
	
		
	}
	if (map[j][i + 1] != '\n')
			{
				printf("Error: top row not enclosed\n");
				//printf("j %d, i %d \n", j,i);
				return (1);
			}
		return (0);

}


// //return 1 if error
int	check_bottom(char **map)
{
	int		i;
	int		j;
	int flag = 0;
	int max_check;

	write(1, "\033c", 3);
	printf("checking bottom \n ");
	j = ft_array_len(map) - 1;
	if(ft_map_row(map[j]) == 0)
		return (1);
	i = 0;
	
	max_check = ft_strlen(map[j]) * 3;
	while(ft_isspace(map[j][i]) && map[j][i + 1] != '\n')
	{
		i++;
		printf("j %d, i %d \n", j,i);
		
	}
	if(!map[j][i])
		return (1);
	while(map[j][i + 1] != '\n')
	{
		while (map[j][i] == '1' && map[j][i + 1] == '1' && ((j == ft_array_len(map) - 1) || ((j < ft_array_len(map) - 1)  && map[j + 1][i] != '1')))
		{
		i++;
		printf("j %d, i %d \n", j,i);
		
		}
		flag++;
		while (map[j][i] == '1' && map[j - 1][i] && map[j - 1][i] == '1' && map[j][i + 1] == ' ')
				{
				
				j--;
				printf("j %d, i %d \n", j,i);
				}
		flag++;
				//printf("hereree\n");
		while (map[j][i] == '1' && map[j][i + 1] == '1' && ((j == ft_array_len(map) - 1) || ((j < ft_array_len(map) - 1)  && map[j + 1][i + 1] != '0')))
			{
			i++;
			printf("j %d, i %d \n", j,i);
			//printf("hereree\n");
			}
			flag++;
			//printf("hereree\n");
		while (map[j][i] == '1' && (j < ft_array_len(map) - 1) && i > 0 && map[j + 1][i] == '1' && map[j + 1][i - 1] == ' ')
		{
			j++;
			printf("j %d, i %d \n", j,i);
		}
		flag++;
		// while (map[j][i] == '1' && map[j][i + 1] == '1')// && ((j == ft_array_len(map) - 1) || ((j < ft_array_len(map) - 1) && map[j + 1][i - 1]  && map[j + 1][i - 1] == ' ')))
		// {
		// 	i++;
		// 	printf("j %d, i %d \n", j,i);
		// }
		// flag++;
		
		if ( flag > max_check)
			break ;	
	
		
	}
	if (map[j][i + 1] != '\n')
			{
				printf("Error: bottom row not enclosed \n");
				//printf("j %d, i %d \n", j,i);
				return (1);
			}
		return (0);

}


// //return 1 if error
int	check_left(char **map)
{
	int	j;
	int	i;

	int flag1;
	int flag2;


	write(1, "\033c", 3);
	printf("checking left \n ");
	i = 0;
	j = ft_array_len(map) - 2;

	while(j > 0)
	{
		flag1 = 0;
		flag2 = 0;
		i = 0;
		printf("j %d, i %d \n", j,i);
		while(map[j][i] == ' ')
		{
			i++;
			if(map[j][i] == '0')
			{
				printf("left row not enclosed\n");
				printf("j %d, i %d \n", j,i);
				return (1);
			}
		}
		if(map[j][i] != '1')
		{
				printf("left row not enclosed 2\n");
				printf("j %d, i %d \n", j,i);
				return (1);
		}
		while(map[j][i] == '1')
		{
			if (map[j + 1][i] == '1')
				flag1 = 1;
			if (map[j - 1][i] == '1')
				flag2 = 1;
			i++;
		}
		if(flag1 == 0 || flag2 == 0)
		{
			printf("left row not enclosed 3\n");
			printf("j %d, i %d \n", j,i);
			return (1);
		}
		j--;
	}
	printf("left row ok\n");
	return (0);
}

// //return 1 if error
int	check_right(char **map)
{
	int	j;
	int	i;

	int flag;
	//int flag2;


	write(1, "\033c", 3);
	printf("checking right \n ");
	i = 0;
	j = ft_array_len(map) - 2;

	while(j > 0)
	{
		flag = 0;
		//flag2 = 0;
		i = ft_strlen(map[j]) - 2;
		//printf("here is %c\n", map[j][i]);
		if (map[j][i] != '1')
			{
				printf("right row not enclosed 1\n");
				printf("j %d, i %d \n", j,i);
				return (1);
			}
		while(i > 0 && map[j][i] == '1')
		{
			if(map[j - 1][i] == '1')
				flag = 1;
			i--;
		}
		if(flag == 0 )
		{
			printf("right row not enclosed 3\n");
			printf("j %d, i %d \n", j,i);
			return (1);
		}
		j--;
	}
	printf("right row ok\n");
	return (0);

}

int	check_chars(char **map)
{
	write(1, "\033c", 3);
	int	flag;
	int	i;
	int	j;

	flag = 0;
	j = 0;
	while (j < ft_array_len(map))
	{
		i = 0;
		while(i < (int)ft_strlen(map[j]))
		{
			if(map[j][i] == 'N' || map[j][i] == 'S' || map[j][i] == 'W' || map[j][i] == 'E')
				flag++;
			else if(map[j][i] != ' ' && map[j][i] != '1' && map[j][i] != '0' && map[j][i] != '\n')
			{
				printf("map chars not valid 1\n");
				printf("j %d, i %d \n", j,i);
				return (1);
			}
			i++;
		}
		j++;
	}
	if(flag != 1)
			{
				printf("map chars not valid 2\n");
				//printf("j %d, i %d \n", j,i);
				return (1);
			}
	return(0);
}