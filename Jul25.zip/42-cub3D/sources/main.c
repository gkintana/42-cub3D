/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gkintana <gkintana@student.42abudhabi.ae>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/02 01:01:52 by gkintana          #+#    #+#             */
/*   Updated: 2022/07/10 21:32:48 by gkintana         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <cub3D.h>

/*
 * parses the map and sets the player's starting location at the first
 * occurrence of a '0' (N now) character. Will be replaced later to the first
 * occurrence of any of the following characters "N or S or E or W"
 * 
 * i[0] = index for y-axis of map
 * i[1] = index for x-axis of map
 * i[2] = acts like a boolean to indicate if the player's starting
 *        location has been set
 */
void	set_player_position(t_program *prog)
{
	int	i[3];

	i[2] = 0;
	i[0] = -1;
	while (prog->mlx.map[++i[0]])
	{
		i[1] = -1;
		while (prog->mlx.map[i[0]][++i[1]])
		{
			if (prog->mlx.map[i[0]][i[1]] == 'N')
			{
				prog->info.pos_x = i[1] + 0.50;
				prog->info.pos_y = i[0] + 0.50;
				i[2] = 1;
				break ;
			}
		}
		if (i[2])
			break ;
	}
}

int main(int argc, char **argv)
{
	t_program	prog;

	if (argc == 2) 
	{
		ft_bzero(&prog, sizeof(t_program));
		check_map_validity(argv[1]);
		printf("passed is file\n");
		check_map_extension(argv[1]);
		printf("passed is extention\n");
		if (check_elements(argv[1]) == 0)
		{
			//write(1, "\033c", 3);
			//printf("success uptil map checking\n");
			init(&prog, argv[1]);
			raycast_loop(&prog);
			mlx_hook(prog.mlx.window, 2, 1L<<0, key_events, &prog);
			mlx_loop(prog.mlx.ptr);
			return (0);
		}
	}
	ft_putstr_fd("Invalid Arguments\n", 2);
	return (1);
}