/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rrangwan <rrangwan@42abudhabi.ae>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/03 17:13:58 by rrangwan          #+#    #+#             */
/*   Updated: 2022/06/29 21:47:53 by rrangwan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "music.h"

# include "miniaudio/miniaudio.c"

int music(char *path)
{
    ma_result result;
    ma_engine engine;

    result = ma_engine_init(NULL, &engine);
    if (result != MA_SUCCESS) {
        printf("Audio Failed");
        return -1;
    }

    ma_engine_play_sound(&engine, path, NULL);

    printf("Press Enter to stop music...");
    getchar();

    ma_engine_uninit(&engine);

    return 0;
}