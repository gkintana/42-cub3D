
#ifndef MUSIC_H
# define MUSIC_H

# include <unistd.h>
# include <stdio.h>
# include <stdlib.h>
# include <pthread.h>
# include <sys/time.h>
# include <math.h>

# include "miniaudio/miniaudio.h"


int music(char *path);

#endif
