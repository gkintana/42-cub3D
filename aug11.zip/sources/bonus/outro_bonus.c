/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   init1.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rrangwan <rrangwan@42abudhabi.ae>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/09 02:00:52 by rrangwan          #+#    #+#             */
/*   Updated: 2022/08/10 20:00:54 by rrangwan         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <cub3D_bonus.h>
#include <miniaudio_bonus.h>

static	void	start_slideshow2(t_program *prog, void *pic[])
{
	mlx_put_image_to_window(prog->mlx.ptr, prog->mlx.window, pic[0], 0, 0);
	sleep(2);
	mlx_clear_window(prog->mlx.ptr, prog->mlx.window);
	mlx_put_image_to_window(prog->mlx.ptr, prog->mlx.window, pic[1], 0, 0);
	sleep(2);
	mlx_clear_window(prog->mlx.ptr, prog->mlx.window);
	mlx_put_image_to_window(prog->mlx.ptr, prog->mlx.window, pic[2], 0, 0);
	sleep(2);
	mlx_clear_window(prog->mlx.ptr, prog->mlx.window);
	mlx_put_image_to_window(prog->mlx.ptr, prog->mlx.window, pic[3], 0, 0);
}

static void	init_outro_images(t_program *prog, void *pic[], int width[],
			int height[])
{
	pic[0] = mlx_xpm_file_to_image(prog->mlx.ptr, "assets/outro/1.xpm",
		&width[0], &height[0]);
	pic[1] = mlx_xpm_file_to_image(prog->mlx.ptr, "assets/outro/2.xpm",
		&width[1], &height[1]);
	pic[2] = mlx_xpm_file_to_image(prog->mlx.ptr, "assets/outro/3.xpm",
		&width[2], &height[2]);
	pic[3] = mlx_xpm_file_to_image(prog->mlx.ptr, "assets/outro/4.xpm",
		&width[3], &height[3]);
}

void	play_outro(t_program *prog)
{
	int		width[4];
	int		height[4];
	void	*pic[4];

	mlx_clear_window(prog->mlx.ptr, prog->mlx.window);
	ft_bzero(pic, sizeof(void *) * 4);
	init_outro_images(prog, pic, width, height);
	start_slideshow2(prog, pic);
	music("assets/outro/song3.mp3", 13);
	mlx_clear_window(prog->mlx.ptr, prog->mlx.window);
	destroy_intro_images(prog, pic);
	ft_bzero(pic, sizeof(void *) * 4);
}
