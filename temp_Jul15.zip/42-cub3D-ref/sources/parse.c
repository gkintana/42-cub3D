/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parse.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gkintana <gkintana@student.42abudhabi.ae>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/09 02:00:52 by gkintana          #+#    #+#             */
/*   Updated: 2022/07/09 02:01:03 by gkintana         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <cub3D.h>

/*
 * this function simply checks if the argument being passed is a file with a
 * .cub extension.
 * 
 * Note: will still work or sometimes even segfault when given invalid
 * 		 arguments
 */

char	*ft_strchr(const char *s, int c)
{
	char	*str;
	int		n;
	int		i;

	str = (char *)s;
	if (!c)
		return (str + ft_strlen(str));
	n = ft_strlen(str);
	i = 0;
	while (i < n)
	{
		if (str[i] == (char)c)
			return (str + i);
		i++;
	}
	return (0);
}

void	check_map_extension(char *file)
{
	char	*ext;

	ext = ft_strrchr(file, '.');
	//printf("%s\n", ext);
	if (ft_strncmp(ext, ".cub", 4) != 0) 
	{	
		ft_putstr_fd("Error: Invalid Map Extension\n", 2);
		exit(1);
	}
	ext = ft_strchr(file, '.');
	//printf("%s\n", ext);
	if (ft_strlen(ext) != 4)
	{	
		ft_putstr_fd("Error: Invalid Map Extension\n", 2);
		exit(1);
	}
}

// int find_errors(char *line)
// {
// 	(void) line;
// 	return(0);
// }

/*
 * function intended to parse map before proceding with the initializations,
 * calculations, raycasting, etc.
 */

//check map_validitiy first before check map_extension, to avoid seg fault if directroy
void	check_map_validity(char *file)
{
	//char	*str;
	int		fd;
	//int		i;

	fd = open(file,__O_DIRECTORY | __O_PATH);
	//printf("%d\n", fd);
	if (fd != -1)
	{
		ft_putstr_fd("Error: Argument Not a file\n", 2);
		exit (1);
	}
	fd = open(file, O_RDONLY);
	if (fd == -1)
	{
		ft_putstr_fd("Error: Map file does not exist\n", 2);
		exit (1);
	}
	close(fd);
}

/*
 * saves the map in a 2d array if it passes the parser
 */
// char	**save_map(char *file, int lines)
// {
// 	char	**map;
// 	char	*temp;
// 	int		fd;
// 	int		i;

// 	map = (char **)ft_calloc(lines + 1, sizeof(char *));
// 	fd = open(file, O_RDONLY);
// 	temp = get_next_line(fd);
// 	i = 0;
// 	while (temp)
// 	{
// 		map[i++] = ft_strdup(temp);
// 		free(temp);
// 		temp = get_next_line(fd);
// 	}
// 	free(temp);
// 	temp = NULL;
// 	close(fd);
// 	return (map);
// }

void	ft_bzero2(int *array, int len)
{
	int i;

	i = 0;
	while (i < len)
	{
		array[i] = 0;
		i++;
	}
}

//should return 0 if all good
int	check_elements(char *file)
{
	int	fd;
	char *str;
	//char *path;
	int	flag;
	int	i;
	int	*elem;
	char **map_temp;

	elem = (int *)malloc(sizeof(int) * 6);
	map_temp = (char **)malloc(sizeof(char *)*1);
	if(!elem || !map_temp)
		return (1);
	ft_bzero2(elem, 6);
	map_temp[0] = NULL;
	flag = 0;
	fd = open(file, O_RDONLY);
	str = get_next_line(fd);
	//printf("%s\n", str);
	while ((str != NULL))
	{
		printf("while loop in check_elements start\n");
		printf("%s\n", str);
		i = 0;
		while (str[i] && ft_isspace(str[i]))
			i++;
	if (str[i])
		{
			if ((str[i] == 'N' && str[i + 1] && str[i + 1] == 'O' && str[i + 2] && ft_isspace(str[i + 2])) \
				|| (str[i] == 'S' && str[i + 1] && str[i + 1] == 'O' && str[i + 2] && ft_isspace(str[i + 2])) \
				|| (str[i] == 'W' && str[i + 1] && str[i + 1] == 'E' && str[i + 2] && ft_isspace(str[i + 2])) \
				|| (str[i] == 'E' && str[i + 1] && str[i + 1] == 'A' && str[i + 2] && ft_isspace(str[i + 2])))
			{
				if (str[i] == 'N')
					elem[0]++;
				else if (str[i] == 'S')
					elem[1]++;
				else if (str[i] == 'W')
					elem[2]++;
				else if (str[i] == 'E')
					elem[3]++;
				i += 2;
				while (str[i + 1] && ft_isspace(str[i]) && str[i] != '\n')
					i++;
				printf("what is this char %c \n", str[i]);
				if (str[i])
				{
					printf("flag is %d\n", flag);
					flag += ft_path(str, i);
					printf("flag is %d\n", flag);
					if (flag > 0)
					{
						free (str);
						printf("failure\n");
						return (1);
					}
			
				}
				else
					{
						free (str);
						return (1);
					}

			}
			else if ((str[i] == 'F' && str[i + 1] && ft_isspace(str[i + 1])) \
					|| (str[i] == 'C' && str[i + 1] && ft_isspace(str[i + 1])))
			{
				printf("else if F or C\n");
				if (str[i] == 'F')
					elem[4]++;
				else if (str[i] == 'C')
					elem[5]++;
				i ++;
				while (str[i + 1] && ft_isspace(str[i]) && str[i] != '\n')
					i++;
				if (str[i])
				{
					printf("flag is  %d\n", flag);
					flag += ft_rgb(str, i);
					printf("flag is %d\n", flag);
					if (flag > 0)
					{
						free (str);
						printf("failure\n");
						return (1);
					}
				}
				else
					{
						free (str);
						printf("failure\n");
						return (1);
					}
			}
			else if (ft_map_row(str))
			{
				
				printf("this is start of map\n");
				flag = 0;
				i = 0;
				while(str)
				{
					// i = check_map(str, i);
					// if ( 1 < 0)
					// {
					// 	free (str);
					// 	printf("Error: Invalid components for map\n");
					// 	return (1);

					// }
					//i is now number of rows of map
					map_temp = ft_temp_map(map_temp, str);
					free (str);
					str = NULL;
					str = get_next_line(fd);
				}
				//ft_temp_map(map_temp, NULL);
				free (str);
				//printf("testing map in heeeerreee %s \n", map_temp[1]);
				return (check_map(map_temp));
			}
			else
			{
								
				free (str);
				printf("Error: Invalid inputs in file\n");
				return (1);
					
			}
			// else if (flag != 0)
			// 		{
			// 			free (str);
			// 			return (1);
			
			// 		}
		}	
			free (str);
			str = NULL;
			str = get_next_line(fd);
		
	}
	printf("exit while\n");
	free (str);
	str = NULL;
	close (fd);
	if (ft_elem(elem, 6))
	{
		ft_putstr_fd("Error: Invalid Map Elements\n", 2);
		free (elem);
		return (1);
	}
	free (elem);
	return (0);
}

//should return 0 if not map first row
int	ft_map_row(char *str)
{
	int	i;
	//printf("start map_row \n");
	//printf("map_row %s\n", str);
	i = 0;
	while(str[i] != '\n')
	{
		//printf("printing map row char %c \n", str[i]);
		if((str[i] != ' ' && str[i] != '1'))
		{
			//printf("not map row\n");
			return (0);
		}
		i++;
	}
	//printf("is map row\n");
	return (1);
}
	

//should return 0 if all good
int	ft_path(char *str, int i)
{
	char	*ret;
	int		j;
	int		len;
	int		fd;

	j = i;
	printf("start ft_path\n");
	while(!ft_isspace(str[j]))
		j++;
	len = j - i;
	j = 0;
	ret = (char *)malloc(sizeof(char) * (len + 1));
	if (!ret)
		return (1);
	while(!ft_isspace(str[i]))
	{
		ret[j] = str[i];
		j++;
		i++;
	}
	ret[j] = '\0';
	//printf("ft_path %s\n",ret);
	fd = open(ret,__O_DIRECTORY | __O_PATH);
	//printf("%d\n", fd);
	if (fd != -1)
	{
		printf("Error: texture path %s not a file\n", ret);
		return (1);
	}
	fd = open(ret, O_RDONLY);
	if (fd == -1)
	{
		printf("Error: texture path %s not accessible\n", ret);
		return (1);
	}
	close(fd);
	free (ret);
	ret = NULL;
	printf("pass ft_path\n");
	return (0);
}

int		ft_array_len(char **array)
{
	int	ret;

	ret = 0;
	if (array)
	{
		while(array[ret] != NULL)
			ret++;
	}
	return (ret);
		
}

// char	**ft_split2(char const *s, char c)
// {
// 	char	temp[700000];
// 	int		i;

// 	if(!s)
// 		return (NULL);
// 	ft_memset(temp, '\0', 700000);
// 	i = 0;
// 	while(s[i])
// 	{
// 		if(!ft_isspace(s[i]))
// 			temp[i] = s[i];
// 		i++;
// 	}
// 	printf("ft_split 2 result %s\n", temp);
// 	return (ft_split(temp, c));
// }

//should return 0 if all good
int	ft_rgb(char *str, int i)
{
	char	*ret;
	int		j;
	//int		len;
	//int		k;
	//int		fd;
	char	*temp;
	char	**temp2;
	//int		flag;

	printf("start rgb 1 %s\n", str);
	temp = (char *)malloc(sizeof(char) * 4097);
	if (!temp)
		return (1);
	ft_memset(temp, '\0', 4097);
	//flag = 0;
	j = 0;
	while(str[i])
	{
		if(!ft_isspace(str[i]))
		{
			temp[j] = str[i];
			j++;
		}
		i++;
	}
	ret = (char *)malloc(sizeof(char) * (ft_strlen(temp) + 1));
	j = 0;
	printf("temp in rgb looks like %s\n", temp);
	while (temp[j] != '\0')
	{
		ret[j] = temp[j];
		j++;
	}
	ret[j] = '\0';
	free(temp);
	printf("ft_Rgb 2 %s\n",ret);
	temp2 = ft_split(ret, ',');
	free (ret);
	if (ft_array_len(temp2) != 3)
	{
			free_2d_array(temp2);
			printf("rgb failed not 3 info\n");
			return(1);
	}
	i = 0;
	while(i < 3)
	{
		printf("atoi %d\n", ft_atoi2(temp2[i]));
		if (!(ft_atoi2(temp2[i]) >= 0 && ft_atoi2(temp2[i]) <= 255))
		{
			free_2d_array(temp2);
			printf("rgb fail not atoi\n");
			return(1);
		}
		i++;
	}
	free_2d_array(temp2);
	printf("rgb pass\n");
	return (0);
}


//should return 0 if all good
int	ft_elem(int *array, int len)
{
	int i;

	i = 0;
	while (i < len)
	{
		if (array[i] != 1)
			return (1);
		i++;
	}
	printf("ft_elem passed\n");
	return (0);
}

//returns -1 if error
int	ft_atoi2(const char *str)
{
	int		i;
	size_t	num;

	i = 0;
	num = 0;
	while (ft_isspace(str[i]) == 1)
		i++;
	while(str[i])
	{
		if (!(str[i] >= 48 && str[i] <= 57))
			return (-1);
		num = (num * 10) + (str[i++] - 48);
	}
	if (num > INT32_MAX)
		return (-1);
	else
		return (num);
}
