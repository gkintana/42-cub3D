/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parse2.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gkintana <gkintana@student.42abudhabi.ae>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/09 02:00:52 by gkintana          #+#    #+#             */
/*   Updated: 2022/07/09 02:01:03 by gkintana         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <cub3D.h>

/*Now checking if the map is valid
 */

char	**ft_temp_map(char **map_temp, char *str)
{
	char	**new_temp;
	int		rows;
	int		i;

	// if(!map_temp)
	// 	rows = 0;
	// else
	rows = ft_array_len(map_temp);
	
	
	new_temp = (char **)malloc(sizeof(char *) * (rows + 2));
	if (!new_temp)
		return (NULL);
	i = 0;
	while(map_temp[i])
	{
		new_temp[i] = ft_strdup(map_temp[i]);
		i++;
	}
	new_temp[i] = ft_strdup(str);
	new_temp[i + 1] = NULL;
	//printf("printing ft_temp_map %s \n", new_temp[i]);
	free(map_temp);
	return(new_temp);
}






//return 0 if ok
int	check_map(char **map)
{
	(void)map;
	printf("map checking work under process\n");
/*
	if (check_top(map) || check_bottom(map) || check_left(map) || check_right(map) \
	|| check_chars(map) || check_chars2(map))
		return (1);*/
	return(0);
}

// //return 1 if error
int	check_top(char **map)
{
	int		i;
	int		j;

	if(ft_map_row(map[0]) == 0)
		return (1);
	i = 0;
	j = 1;
	while(map[0][i] != '\n')
	{
		while(ft_isspace(map[0][i]))
			i++;
		while(!ft_isspace(map[0][i]))
			i++;
		if(ft_isspace(map[0][i]) && map[0][i] != '\n')
		{
			while(map[j][i] && ft_isspace(map[j][i]) && map[j][i] != '\n')
			{
				if(map[j][i - 1] != '1')
					return (1);
				j++;	 
			}
		}

	}
	return (0);
}


int	check_bottom(char **map)
{
	if(ft_map_row(map[ft_array_len(map) - 1]) == 0)
		return (1);
	return(0);
}