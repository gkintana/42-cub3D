/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gkintana <gkintana@student.42abudhabi.ae>  +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/07/02 01:01:52 by gkintana          #+#    #+#             */
/*   Updated: 2022/07/29 17:47:31 by gkintana         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <cub3D.h>
//added these
# include <math.h>
# include <miniaudio.h>
int music(char *path);

// int	close_window2(t_program *prog)
// {
// 	mlx_destroy_window(prog->mlx.ptr, prog->mlx.window);
// 	//free(prog->mlx.window);
// 	prog->mlx.window = NULL;
// 	free(prog->mlx.ptr);
// 	prog->mlx.ptr = NULL;
// 	exit(0);
// }

// int	close_window3(t_program *prog)
// {
// 	//stop music
// 	//init cub3d
// }

// int	key_events2(int input, t_program *prog)
// {
// 	if (input == KEYCODE_ESC)
// 		close_window2(prog);
// 	else if (input == 13) //enter key
// 		close_window3(prog);
// 	return (0);
// }

//added this
void	start_intro2(t_program *prog, void *pic)
{
	mlx_put_image_to_window(prog->mlx.ptr, prog->mlx.window, pic, 0, 0);
	sleep(2);
	mlx_clear_window(prog->mlx.ptr, prog->mlx.window);
	mlx_destroy_image(prog->mlx.ptr, pic);
	pic = NULL;

}
//added this
void	start_intro(t_program *prog)
{
	int		width[3];
	int		height[3];
	void	*pic[3];

	
	ft_bzero2(width, 3);
	ft_bzero2(height, 3);
	ft_bzero(pic, 3);
	pic[0] = mlx_xpm_file_to_image(prog->mlx.ptr, "bonus/pic0.xpm", &width[0], &height[0]);
	pic[1] = mlx_xpm_file_to_image(prog->mlx.ptr, "bonus/pic1.xpm", &width[1], &height[1]);
	pic[2] = mlx_xpm_file_to_image(prog->mlx.ptr, "bonus/pic2.xpm", &width[2], &height[2]);
	start_intro2(prog, pic[0]);
	start_intro2(prog, pic[1]);
	start_intro2(prog, pic[2]);
	music("assets/song.mp3");
}

int main(int argc, char **argv)
{
	 (void)argc;
	 (void)argv;

	 t_program prog;

	 if (argc == 2) 
	 {
	 	ft_bzero(&prog, sizeof(t_program));
		check_map_validity(argv[1]);
		check_map_extension(argv[1]);
		if (check_elements(argv[1], &prog) == 0)
		{
			
			init_mlx(&prog);
			start_intro(&prog); //added this
			init_images(&prog); //moved to here
			raycast_loop(&prog);
			mlx_hook(prog.mlx.window, 2, 1L<<0, key_events, &prog);
			mlx_hook(prog.mlx.window, 6, 1L<<6, mouse_events, &prog);
			mlx_hook(prog.mlx.window, 17, 1L<<17, close_window, &prog);
			mlx_loop(prog.mlx.ptr);
		
			// free(prog.tex.ceiling);
			// free(prog.tex.floor);
			// free(prog.tex.north);
			// free(prog.tex.east);
			// free(prog.tex.west);
			// free(prog.tex.south);
			// free_2d_array(prog.mlx.map);
			
			printf("OK\n");
			return (0);
		}
	}
	ft_putstr_fd("Invalid Arguments\n", 2);
	return (1);
}


